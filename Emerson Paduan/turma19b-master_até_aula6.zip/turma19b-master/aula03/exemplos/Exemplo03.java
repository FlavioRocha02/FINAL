package exemplos;

public class Exemplo03 {
    public static void main(String[] args) {
        // int cont;

        for (int cont = 1; cont <= 15; cont++) {
            System.out.println(cont);

        }

        // System.out.println("fim: " + cont);

    }
}
