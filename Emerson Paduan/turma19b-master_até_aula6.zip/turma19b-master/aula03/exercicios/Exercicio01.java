package exercicios;

public class Exercicio01 {
    public static void main(String[] args) {
        int cont;

        cont = 100; 
        while (cont <= 200) { 
            // System.out.print(cont + " ");
            System.out.printf("%d ", cont);
            cont++; 

        }
    }
}
