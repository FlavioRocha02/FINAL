package exemplos;

public class Exemplo03 {
    public static void main(String[] args) {
        System.out.println(3 + 4);
        System.out.println(3 > 4);
        System.out.println(3 <= 4);

    }
}
