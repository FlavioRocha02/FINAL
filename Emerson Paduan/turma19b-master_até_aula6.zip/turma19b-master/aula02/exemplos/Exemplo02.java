package exemplos;

public class Exemplo02 {
    public static void main(String[] args) {
        int idade;

        idade = 15;

        if (idade >= 18) {
            System.out.println("Você já pode dirigir.");
        } else {
            System.out.println("Você não pode dirigir.");
        }

        System.out.println("Fim do programa.");

    }
}
