# Treinamento Itaú-Gama

## Atalhos úteis VSCode
https://gist.github.com/EmersonPaduan/6e23ae9be6d1c0213774957ca61fdf82

---

## Links úteis GIT

### Resumão do Git
https://training.github.com/downloads/pt_BR/github-git-cheat-sheet.pdf

### Aprender Git visualmente
https://learngitbranching.js.org/

### Git HowTo
https://githowto.com/pt-BR/

---

### Http Status Codes
https://developer.mozilla.org/pt-BR/docs/Web/HTTP/Status

---

## Spring

### JPA Query Methods
https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#jpa.query-methods

---