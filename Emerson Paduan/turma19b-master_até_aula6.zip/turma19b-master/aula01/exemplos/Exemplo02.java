package exemplos;

public class Exemplo02 {

    public static void main(String[] args) {
        System.out.println(2 + 3);
        System.out.println("2 + 3"); // ALT + SHIFT + SETA
        System.out.println("2 + 3 = " + 2 + 3);
        System.out.println("2 + 3 = " + (2 + 3) );
        
        // Operadores aritméticos: + - * /
    }

}
