package exemplos;

/*
  Exemplo01
 */

public class Exemplo01 {
    public static void main(String[] args) { // main = principal
        // syso - atalho
        // print - não muda de linha
        // println pula para próxima linha
        System.out.print("Olá mundo! ");
        System.out.println("Emeson");
        System.out.println("Linha1\nlinha2\nlinha3"); // \n = nova linha
    }

}
