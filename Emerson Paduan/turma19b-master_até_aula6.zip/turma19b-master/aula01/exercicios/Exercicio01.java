package exercicios;

public class Exercicio01 {
    public static void main(String[] args) {
        
        System.out.println("17 + 5 = " + (17 + 5));
        System.out.println("17 - 5 = " + (17 - 5));
        System.out.println("17 * 5 = " + (17 * 5));
        System.out.println("17 / 5 = " + (17.0 / 5));
        
    }
}
